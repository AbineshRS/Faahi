﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class category : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "im_item_Category",
                columns: table => new
                {
                    item_class_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    company_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    item_class = table.Column<string>(type: "varchar(20)", nullable: true),
                    description = table.Column<string>(type: "varchar(200)", nullable: true),
                    categoryType = table.Column<string>(type: "varchar(20)", nullable: true),
                    item_count = table.Column<int>(type: "int", nullable: true),
                    Sales_count = table.Column<int>(type: "int", nullable: true),
                    code = table.Column<string>(type: "varchar(10)", nullable: true),
                    item_cat_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    edit_user_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    edit_date_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    categoryImage = table.Column<string>(type: "varchar(max)", nullable: true),
                    status = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    publish = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_item_Category", x => x.item_class_id);
                });

            migrationBuilder.CreateTable(
                name: "im_item_subcategory",
                columns: table => new
                {
                    item_subclass_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    item_class_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    company_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    description = table.Column<string>(type: "varchar(200)", nullable: true),
                    edit_date_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    edit_user_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    status = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    im_item_Categoryitem_class_id = table.Column<string>(type: "varchar(20)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_item_subcategory", x => x.item_subclass_id);
                    table.ForeignKey(
                        name: "FK_im_item_subcategory_im_item_Category_im_item_Categoryitem_class_id",
                        column: x => x.im_item_Categoryitem_class_id,
                        principalTable: "im_item_Category",
                        principalColumn: "item_class_id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_im_item_subcategory_im_item_Categoryitem_class_id",
                table: "im_item_subcategory",
                column: "im_item_Categoryitem_class_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "im_item_subcategory");

            migrationBuilder.DropTable(
                name: "im_item_Category");
        }
    }
}
