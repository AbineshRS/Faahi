﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class im_product_changes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_im_ProductImages_im_ProductVariants_im_ProductVariantsvariant_id",
                table: "im_ProductImages");

            migrationBuilder.DropForeignKey(
                name: "FK_im_Products_im_ProductCategories_im_ProductCategoriescategory_id",
                table: "im_Products");

            migrationBuilder.DropIndex(
                name: "IX_im_Products_im_ProductCategoriescategory_id",
                table: "im_Products");

            migrationBuilder.DropIndex(
                name: "IX_im_ProductImages_im_ProductVariantsvariant_id",
                table: "im_ProductImages");

            migrationBuilder.DropColumn(
                name: "im_ProductCategoriescategory_id",
                table: "im_Products");

            migrationBuilder.DropColumn(
                name: "im_ProductVariantsvariant_id",
                table: "im_ProductImages");

            migrationBuilder.AddColumn<string>(
                name: "im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages",
                type: "varchar(20)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "im_PriceTiers",
                columns: table => new
                {
                    price_tier_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    variant_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    name = table.Column<string>(type: "varchar(50)", nullable: true),
                    description = table.Column<string>(type: "varchar(max)", nullable: true),
                    im_ProductVariantsvariant_id = table.Column<string>(type: "varchar(30)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_PriceTiers", x => x.price_tier_id);
                    table.ForeignKey(
                        name: "FK_im_PriceTiers_im_ProductVariants_im_ProductVariantsvariant_id",
                        column: x => x.im_ProductVariantsvariant_id,
                        principalTable: "im_ProductVariants",
                        principalColumn: "variant_id");
                });

            migrationBuilder.CreateTable(
                name: "im_ProductVariantPrices",
                columns: table => new
                {
                    variant_price_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    variant_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    company_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    price_tier_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    price = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    currency = table.Column<string>(type: "varchar(20)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    updated_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    im_PriceTiersprice_tier_id = table.Column<string>(type: "varchar(20)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_ProductVariantPrices", x => x.variant_price_id);
                    table.ForeignKey(
                        name: "FK_im_ProductVariantPrices_im_PriceTiers_im_PriceTiersprice_tier_id",
                        column: x => x.im_PriceTiersprice_tier_id,
                        principalTable: "im_PriceTiers",
                        principalColumn: "price_tier_id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_im_ProductImages_im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages",
                column: "im_ProductVariantPricesvariant_price_id");

            migrationBuilder.CreateIndex(
                name: "IX_im_PriceTiers_im_ProductVariantsvariant_id",
                table: "im_PriceTiers",
                column: "im_ProductVariantsvariant_id");

            migrationBuilder.CreateIndex(
                name: "IX_im_ProductVariantPrices_im_PriceTiersprice_tier_id",
                table: "im_ProductVariantPrices",
                column: "im_PriceTiersprice_tier_id");

            migrationBuilder.AddForeignKey(
                name: "FK_im_ProductImages_im_ProductVariantPrices_im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages",
                column: "im_ProductVariantPricesvariant_price_id",
                principalTable: "im_ProductVariantPrices",
                principalColumn: "variant_price_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_im_ProductImages_im_ProductVariantPrices_im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages");

            migrationBuilder.DropTable(
                name: "im_ProductVariantPrices");

            migrationBuilder.DropTable(
                name: "im_PriceTiers");

            migrationBuilder.DropIndex(
                name: "IX_im_ProductImages_im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages");

            migrationBuilder.DropColumn(
                name: "im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages");

            migrationBuilder.AddColumn<string>(
                name: "im_ProductCategoriescategory_id",
                table: "im_Products",
                type: "varchar(20)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "im_ProductVariantsvariant_id",
                table: "im_ProductImages",
                type: "varchar(30)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_im_Products_im_ProductCategoriescategory_id",
                table: "im_Products",
                column: "im_ProductCategoriescategory_id");

            migrationBuilder.CreateIndex(
                name: "IX_im_ProductImages_im_ProductVariantsvariant_id",
                table: "im_ProductImages",
                column: "im_ProductVariantsvariant_id");

            migrationBuilder.AddForeignKey(
                name: "FK_im_ProductImages_im_ProductVariants_im_ProductVariantsvariant_id",
                table: "im_ProductImages",
                column: "im_ProductVariantsvariant_id",
                principalTable: "im_ProductVariants",
                principalColumn: "variant_id");

            migrationBuilder.AddForeignKey(
                name: "FK_im_Products_im_ProductCategories_im_ProductCategoriescategory_id",
                table: "im_Products",
                column: "im_ProductCategoriescategory_id",
                principalTable: "im_ProductCategories",
                principalColumn: "category_id");
        }
    }
}
