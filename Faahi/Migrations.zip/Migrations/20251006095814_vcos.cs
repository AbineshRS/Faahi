﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class vcos : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "am_vcos",
                columns: table => new
                {
                    vcos_id = table.Column<string>(type: "varchar(16)", nullable: false),
                    vcos_type = table.Column<string>(type: "varchar(10)", nullable: true),
                    name = table.Column<string>(type: "varchar(150)", nullable: false),
                    address = table.Column<string>(type: "varchar(150)", nullable: true),
                    telephone_1 = table.Column<string>(type: "varchar(32)", nullable: true),
                    telephone_2 = table.Column<string>(type: "varchar(32)", nullable: true),
                    contact_person = table.Column<string>(type: "varchar(32)", nullable: true),
                    fax = table.Column<string>(type: "varchar(32)", nullable: true),
                    email = table.Column<string>(type: "varchar(100)", nullable: true),
                    web = table.Column<string>(type: "varchar(100)", nullable: true),
                    state = table.Column<string>(type: "varchar(32)", nullable: true),
                    postal_code = table.Column<string>(type: "varchar(12)", nullable: true),
                    country = table.Column<string>(type: "varchar(32)", nullable: true),
                    TIN = table.Column<string>(type: "varchar(20)", nullable: true),
                    credit_days = table.Column<int>(type: "int", nullable: true),
                    credit_limit_amount = table.Column<decimal>(type: "decimal(14,2)", nullable: true),
                    trade_discount_percent = table.Column<decimal>(type: "decimal(6,2)", nullable: true),
                    current_balance = table.Column<decimal>(type: "decimal(16,2)", nullable: true),
                    bank_code = table.Column<string>(type: "varchar(16)", nullable: true),
                    bank_account_number = table.Column<string>(type: "varchar(24)", nullable: true),
                    Registered_date = table.Column<DateTime>(type: "datetime", nullable: false),
                    edit_date_time = table.Column<DateTime>(type: "datetime", nullable: false),
                    edit_user_id = table.Column<string>(type: "varchar(16)", nullable: false),
                    status = table.Column<string>(type: "char(1)", maxLength: 1, nullable: false),
                    currency_id = table.Column<string>(type: "varchar(16)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_am_vcos", x => x.vcos_id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "am_vcos");
        }
    }
}
