﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class currencylist : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_im_PriceTiers_im_ProductVariants_im_ProductVariantsvariant_id",
                table: "im_PriceTiers");

            migrationBuilder.DropForeignKey(
                name: "FK_im_ProductImages_im_ProductVariantPrices_im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages");

            migrationBuilder.DropIndex(
                name: "IX_im_ProductImages_im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages");

            migrationBuilder.DropIndex(
                name: "IX_im_PriceTiers_im_ProductVariantsvariant_id",
                table: "im_PriceTiers");

            migrationBuilder.DropColumn(
                name: "im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages");

            migrationBuilder.RenameColumn(
                name: "variant_id",
                table: "im_ProductVariantPrices",
                newName: "sub_variant_id");

            migrationBuilder.RenameColumn(
                name: "category_id",
                table: "im_Products",
                newName: "item_subclass_id");

            migrationBuilder.RenameColumn(
                name: "im_ProductVariantsvariant_id",
                table: "im_PriceTiers",
                newName: "sub_variant_id");

            migrationBuilder.AddColumn<string>(
                name: "item_class_id",
                table: "im_Products",
                type: "varchar(20)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "im_product_subvariantsub_variant_id",
                table: "im_PriceTiers",
                type: "varchar(30)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "co_avl_countries",
                columns: table => new
                {
                    id = table.Column<string>(type: "varchar(5)", nullable: false),
                    name = table.Column<string>(type: "varchar(100)", nullable: false),
                    country_code = table.Column<string>(type: "varchar(16)", nullable: true),
                    flag = table.Column<string>(type: "varchar(150)", nullable: true),
                    dialling_code = table.Column<string>(type: "varchar(16)", nullable: true),
                    currency_code = table.Column<string>(type: "varchar(16)", nullable: true),
                    currency_name = table.Column<string>(type: "varchar(100)", nullable: true),
                    serv_available = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_co_avl_countries", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "im_product_subvariant",
                columns: table => new
                {
                    sub_variant_id = table.Column<string>(type: "varchar(30)", nullable: false),
                    variant_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    product_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    variantType = table.Column<string>(type: "varchar(50)", nullable: true),
                    variantValue = table.Column<string>(type: "varchar(50)", nullable: true),
                    list_price = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    standard_cost = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    last_cost = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    avg_cost = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    ws_price = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    profit_p = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    minimum_selling = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    item_barcode = table.Column<string>(type: "varchar(50)", nullable: true),
                    modal_number = table.Column<string>(type: "varchar(50)", nullable: true),
                    shipping_weight = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    shipping_length = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    shipping_width = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    shipping_height = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    total_volume = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    total_weight = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    deduct_qnty = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    quantity = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    edit_user_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    unit_breakdown = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    fixed_price = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    generateBarcode = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    im_ProductVariantsvariant_id = table.Column<string>(type: "varchar(30)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_product_subvariant", x => x.sub_variant_id);
                    table.ForeignKey(
                        name: "FK_im_product_subvariant_im_ProductVariants_im_ProductVariantsvariant_id",
                        column: x => x.im_ProductVariantsvariant_id,
                        principalTable: "im_ProductVariants",
                        principalColumn: "variant_id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_im_PriceTiers_im_product_subvariantsub_variant_id",
                table: "im_PriceTiers",
                column: "im_product_subvariantsub_variant_id");

            migrationBuilder.CreateIndex(
                name: "IX_im_product_subvariant_im_ProductVariantsvariant_id",
                table: "im_product_subvariant",
                column: "im_ProductVariantsvariant_id");

            migrationBuilder.AddForeignKey(
                name: "FK_im_PriceTiers_im_product_subvariant_im_product_subvariantsub_variant_id",
                table: "im_PriceTiers",
                column: "im_product_subvariantsub_variant_id",
                principalTable: "im_product_subvariant",
                principalColumn: "sub_variant_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_im_PriceTiers_im_product_subvariant_im_product_subvariantsub_variant_id",
                table: "im_PriceTiers");

            migrationBuilder.DropTable(
                name: "co_avl_countries");

            migrationBuilder.DropTable(
                name: "im_product_subvariant");

            migrationBuilder.DropIndex(
                name: "IX_im_PriceTiers_im_product_subvariantsub_variant_id",
                table: "im_PriceTiers");

            migrationBuilder.DropColumn(
                name: "item_class_id",
                table: "im_Products");

            migrationBuilder.DropColumn(
                name: "im_product_subvariantsub_variant_id",
                table: "im_PriceTiers");

            migrationBuilder.RenameColumn(
                name: "sub_variant_id",
                table: "im_ProductVariantPrices",
                newName: "variant_id");

            migrationBuilder.RenameColumn(
                name: "item_subclass_id",
                table: "im_Products",
                newName: "category_id");

            migrationBuilder.RenameColumn(
                name: "sub_variant_id",
                table: "im_PriceTiers",
                newName: "im_ProductVariantsvariant_id");

            migrationBuilder.AddColumn<string>(
                name: "im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages",
                type: "varchar(20)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_im_ProductImages_im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages",
                column: "im_ProductVariantPricesvariant_price_id");

            migrationBuilder.CreateIndex(
                name: "IX_im_PriceTiers_im_ProductVariantsvariant_id",
                table: "im_PriceTiers",
                column: "im_ProductVariantsvariant_id");

            migrationBuilder.AddForeignKey(
                name: "FK_im_PriceTiers_im_ProductVariants_im_ProductVariantsvariant_id",
                table: "im_PriceTiers",
                column: "im_ProductVariantsvariant_id",
                principalTable: "im_ProductVariants",
                principalColumn: "variant_id");

            migrationBuilder.AddForeignKey(
                name: "FK_im_ProductImages_im_ProductVariantPrices_im_ProductVariantPricesvariant_price_id",
                table: "im_ProductImages",
                column: "im_ProductVariantPricesvariant_price_id",
                principalTable: "im_ProductVariantPrices",
                principalColumn: "variant_price_id");
        }
    }
}
