﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class vendors_2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Alter payment_term_id first (nullable column)
            migrationBuilder.AlterColumn<Guid>(
                name: "payment_term_id",
                table: "ap_Vendors",
                type: "uniqueidentifier",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(30)",
                oldNullable: true);

            // Drop the primary key constraint on vendor_id
            migrationBuilder.DropPrimaryKey(
                name: "PK_ap_Vendors",
                table: "ap_Vendors");

            // Alter vendor_id column
            migrationBuilder.AlterColumn<Guid>(
                name: "vendor_id",
                table: "ap_Vendors",
                type: "uniqueidentifier",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "varchar(30)");

            // Re-add the primary key constraint on vendor_id
            migrationBuilder.AddPrimaryKey(
                name: "PK_ap_Vendors",
                table: "ap_Vendors",
                column: "vendor_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Drop primary key before reverting column type
            migrationBuilder.DropPrimaryKey(
                name: "PK_ap_Vendors",
                table: "ap_Vendors");

            // Revert vendor_id back to string
            migrationBuilder.AlterColumn<string>(
                name: "vendor_id",
                table: "ap_Vendors",
                type: "varchar(30)",
                nullable: false,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier");

            // Re-add the primary key
            migrationBuilder.AddPrimaryKey(
                name: "PK_ap_Vendors",
                table: "ap_Vendors",
                column: "vendor_id");

            // Revert payment_term_id back to string
            migrationBuilder.AlterColumn<string>(
                name: "payment_term_id",
                table: "ap_Vendors",
                type: "varchar(30)",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier",
                oldNullable: true);
        }
    }
}
