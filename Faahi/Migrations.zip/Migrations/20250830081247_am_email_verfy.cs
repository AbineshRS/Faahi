﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class am_email_verfy : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "am_emailVerifications",
                columns: table => new
                {
                    Email_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    email = table.Column<string>(type: "varchar(50)", nullable: true),
                    verificationType = table.Column<string>(type: "varchar(30)", nullable: true),
                    tokenExpiryTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    token = table.Column<string>(type: "varchar(max)", nullable: true),
                    isExpired = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    verified = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_am_emailVerifications", x => x.Email_id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "am_emailVerifications");
        }
    }
}
