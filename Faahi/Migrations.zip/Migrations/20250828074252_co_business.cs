﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class co_business : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "co_business",
                columns: table => new
                {
                    company_id = table.Column<string>(type: "varchar(32)", nullable: false),
                    business_name = table.Column<string>(type: "varchar(100)", nullable: true),
                    tin_number = table.Column<string>(type: "varchar(50)", nullable: true),
                    name = table.Column<string>(type: "varchar(50)", nullable: true),
                    password = table.Column<string>(type: "varchar(50)", nullable: true),
                    reg_no = table.Column<string>(type: "varchar(50)", nullable: true),
                    country = table.Column<string>(type: "varchar(20)", nullable: true),
                    address = table.Column<string>(type: "varchar(max)", nullable: true),
                    logo_fileName = table.Column<string>(type: "varchar(50)", nullable: true),
                    phoneNumber = table.Column<string>(type: "varchar(20)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    plan_type = table.Column<string>(type: "varchar(20)", nullable: true),
                    sites_allowed = table.Column<int>(type: "int", nullable: true),
                    createdSites = table.Column<int>(type: "int", nullable: true),
                    edit_date_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    edit_user_id = table.Column<string>(type: "varchar(20)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_co_business", x => x.company_id);
                });

            migrationBuilder.CreateTable(
                name: "co_address",
                columns: table => new
                {
                    company_address_id = table.Column<string>(type: "varchar(32)", nullable: false),
                    company_id = table.Column<string>(type: "varchar(32)", nullable: true),
                    street_1 = table.Column<string>(type: "varchar(60)", nullable: true),
                    street_2 = table.Column<string>(type: "varchar(60)", nullable: true),
                    city = table.Column<string>(type: "varchar(60)", nullable: true),
                    state = table.Column<string>(type: "varchar(60)", nullable: true),
                    postal_code = table.Column<string>(type: "varchar(60)", nullable: true),
                    country = table.Column<string>(type: "varchar(60)", nullable: true),
                    telephone_1 = table.Column<string>(type: "varchar(20)", nullable: true),
                    telephone_2 = table.Column<string>(type: "varchar(20)", nullable: true),
                    email = table.Column<string>(type: "varchar(50)", nullable: true),
                    status = table.Column<string>(type: "char(1)", maxLength: 1, nullable: false),
                    edit_date_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    edit_user_id = table.Column<string>(type: "varchar(16)", nullable: true),
                    co_businesscompany_id = table.Column<string>(type: "varchar(32)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_co_address", x => x.company_address_id);
                    table.ForeignKey(
                        name: "FK_co_address_co_business_co_businesscompany_id",
                        column: x => x.co_businesscompany_id,
                        principalTable: "co_business",
                        principalColumn: "company_id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_co_address_co_businesscompany_id",
                table: "co_address",
                column: "co_businesscompany_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "co_address");

            migrationBuilder.DropTable(
                name: "co_business");
        }
    }
}
