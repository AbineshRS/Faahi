﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class chanhe_in_p_varient : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "allow_below_Zero",
                table: "im_ProductVariants",
                type: "char(1)",
                maxLength: 1,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "low_stock_alert",
                table: "im_ProductVariants",
                type: "char(1)",
                maxLength: 1,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "allow_below_Zero",
                table: "im_ProductVariants");

            migrationBuilder.DropColumn(
                name: "low_stock_alert",
                table: "im_ProductVariants");
        }
    }
}
