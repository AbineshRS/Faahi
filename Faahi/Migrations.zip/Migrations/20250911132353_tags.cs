﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class tags : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "im_products_tag",
                columns: table => new
                {
                    tag_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    item_class_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    item_subclass_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    description = table.Column<string>(type: "varchar(200)", nullable: true),
                    edit_date_time = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_products_tag", x => x.tag_id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "im_products_tag");
        }
    }
}
