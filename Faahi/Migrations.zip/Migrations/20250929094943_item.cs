﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class item : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_co_avl_countries",
                table: "co_avl_countries");

            migrationBuilder.DropColumn(
                name: "id",
                table: "co_avl_countries");

            migrationBuilder.AddColumn<string>(
                name: "avl_countries_id",
                table: "co_avl_countries",
                type: "varchar(15)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_co_avl_countries",
                table: "co_avl_countries",
                column: "avl_countries_id");

            migrationBuilder.CreateTable(
                name: "im_site",
                columns: table => new
                {
                    site_id = table.Column<string>(type: "varchar(30)", nullable: false),
                    company_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    company_address_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    avl_countries_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    site_name = table.Column<string>(type: "varchar(100)", nullable: true),
                    tin_number = table.Column<string>(type: "varchar(100)", nullable: true),
                    edit_user_id = table.Column<string>(type: "varchar(100)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_site", x => x.site_id);
                });

            migrationBuilder.CreateTable(
                name: "im_item_site",
                columns: table => new
                {
                    item_id = table.Column<string>(type: "varchar(30)", nullable: false),
                    site_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    bin_number = table.Column<string>(type: "varchar(20)", nullable: true),
                    primary_vendor_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    on_hand_quantity = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    committed_quantity = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    purchase_order_quantity = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    sales_order_quantity = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    c_price = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    edit_user_id = table.Column<string>(type: "varchar(100)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    on_hold = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    status = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    im_sitesite_id = table.Column<string>(type: "varchar(30)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_item_site", x => x.item_id);
                    table.ForeignKey(
                        name: "FK_im_item_site_im_site_im_sitesite_id",
                        column: x => x.im_sitesite_id,
                        principalTable: "im_site",
                        principalColumn: "site_id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_im_item_site_im_sitesite_id",
                table: "im_item_site",
                column: "im_sitesite_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "im_item_site");

            migrationBuilder.DropTable(
                name: "im_site");

            migrationBuilder.DropPrimaryKey(
                name: "PK_co_avl_countries",
                table: "co_avl_countries");

            migrationBuilder.DropColumn(
                name: "avl_countries_id",
                table: "co_avl_countries");

            migrationBuilder.AddColumn<string>(
                name: "id",
                table: "co_avl_countries",
                type: "varchar(5)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_co_avl_countries",
                table: "co_avl_countries",
                column: "id");
        }
    }
}
