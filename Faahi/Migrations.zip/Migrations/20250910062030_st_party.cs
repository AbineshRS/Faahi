﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class st_party : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "st_Parties",
                columns: table => new
                {
                    party_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    party_type = table.Column<string>(type: "varchar(20)", nullable: false),
                    display_name = table.Column<string>(type: "varchar(200)", nullable: true),
                    legal_name = table.Column<string>(type: "varchar(200)", nullable: true),
                    payable_name = table.Column<string>(type: "varchar(200)", nullable: true),
                    tax_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    email = table.Column<string>(type: "varchar(50)", nullable: true),
                    phone = table.Column<string>(type: "varchar(50)", nullable: true),
                    default_currency = table.Column<string>(type: "varchar(20)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    updated_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_st_Parties", x => x.party_id);
                });

            migrationBuilder.CreateTable(
                name: "st_PartyRoles",
                columns: table => new
                {
                    party_role_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    party_id = table.Column<string>(type: "varchar(30)", nullable: false),
                    role = table.Column<string>(type: "varchar(30)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    st_Partiesparty_id = table.Column<string>(type: "varchar(20)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_st_PartyRoles", x => x.party_role_id);
                    table.ForeignKey(
                        name: "FK_st_PartyRoles_st_Parties_st_Partiesparty_id",
                        column: x => x.st_Partiesparty_id,
                        principalTable: "st_Parties",
                        principalColumn: "party_id");
                });

            migrationBuilder.CreateTable(
                name: "st_PartyAddresses",
                columns: table => new
                {
                    address_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    party_id = table.Column<string>(type: "varchar(30)", nullable: false),
                    address_type = table.Column<string>(type: "varchar(30)", nullable: true),
                    line1 = table.Column<string>(type: "varchar(200)", nullable: true),
                    line2 = table.Column<string>(type: "varchar(200)", nullable: true),
                    region = table.Column<string>(type: "varchar(100)", nullable: true),
                    postal_code = table.Column<string>(type: "varchar(30)", nullable: true),
                    country = table.Column<string>(type: "varchar(100)", nullable: true),
                    latitude = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    longitude = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    updated_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    is_default = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    st_PartyRolesparty_role_id = table.Column<string>(type: "varchar(20)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_st_PartyAddresses", x => x.address_id);
                    table.ForeignKey(
                        name: "FK_st_PartyAddresses_st_PartyRoles_st_PartyRolesparty_role_id",
                        column: x => x.st_PartyRolesparty_role_id,
                        principalTable: "st_PartyRoles",
                        principalColumn: "party_role_id");
                });

            migrationBuilder.CreateTable(
                name: "st_PartyContacts",
                columns: table => new
                {
                    contact_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    party_id = table.Column<string>(type: "varchar(30)", nullable: false),
                    first_name = table.Column<string>(type: "varchar(100)", nullable: false),
                    last_name = table.Column<string>(type: "varchar(100)", nullable: true),
                    email = table.Column<string>(type: "varchar(50)", nullable: true),
                    phone = table.Column<string>(type: "varchar(50)", nullable: true),
                    title = table.Column<string>(type: "varchar(100)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    updated_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    is_primary = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    st_PartyAddressesaddress_id = table.Column<string>(type: "varchar(20)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_st_PartyContacts", x => x.contact_id);
                    table.ForeignKey(
                        name: "FK_st_PartyContacts_st_PartyAddresses_st_PartyAddressesaddress_id",
                        column: x => x.st_PartyAddressesaddress_id,
                        principalTable: "st_PartyAddresses",
                        principalColumn: "address_id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_st_PartyAddresses_st_PartyRolesparty_role_id",
                table: "st_PartyAddresses",
                column: "st_PartyRolesparty_role_id");

            migrationBuilder.CreateIndex(
                name: "IX_st_PartyContacts_st_PartyAddressesaddress_id",
                table: "st_PartyContacts",
                column: "st_PartyAddressesaddress_id");

            migrationBuilder.CreateIndex(
                name: "IX_st_PartyRoles_st_Partiesparty_id",
                table: "st_PartyRoles",
                column: "st_Partiesparty_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "st_PartyContacts");

            migrationBuilder.DropTable(
                name: "st_PartyAddresses");

            migrationBuilder.DropTable(
                name: "st_PartyRoles");

            migrationBuilder.DropTable(
                name: "st_Parties");
        }
    }
}
