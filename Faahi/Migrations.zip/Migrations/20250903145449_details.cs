﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class details : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "im_ProductCategories",
                columns: table => new
                {
                    category_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    company_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    category_name = table.Column<string>(type: "varchar(30)", nullable: true),
                    parent_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    image_url = table.Column<string>(type: "varchar(200)", nullable: true),
                    edit_user_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    edit_date_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    is_active = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_ProductCategories", x => x.category_id);
                });

            migrationBuilder.CreateTable(
                name: "im_Products",
                columns: table => new
                {
                    product_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    company_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    category_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    title = table.Column<string>(type: "varchar(200)", nullable: true),
                    description = table.Column<string>(type: "varchar(max)", nullable: true),
                    brand = table.Column<string>(type: "varchar(100)", nullable: true),
                    tax_class = table.Column<string>(type: "varchar(20)", nullable: true),
                    thumbnail_url = table.Column<string>(type: "varchar(200)", nullable: true),
                    HS_CODE = table.Column<string>(type: "varchar(10)", nullable: true),
                    vendor_Code = table.Column<string>(type: "varchar(30)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    updated_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    dutyP = table.Column<decimal>(type: "decimal(16,4)", nullable: true),
                    katta = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    featured_item = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    ignore_direct = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    consign_item = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    free_item = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    iqnore_decimal_qty = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    restrict_HS = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    stock = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    status = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    im_ProductCategoriescategory_id = table.Column<string>(type: "varchar(20)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_Products", x => x.product_id);
                    table.ForeignKey(
                        name: "FK_im_Products_im_ProductCategories_im_ProductCategoriescategory_id",
                        column: x => x.im_ProductCategoriescategory_id,
                        principalTable: "im_ProductCategories",
                        principalColumn: "category_id");
                });

            migrationBuilder.CreateTable(
                name: "im_ProductVariants",
                columns: table => new
                {
                    variant_id = table.Column<string>(type: "varchar(30)", nullable: false),
                    product_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    uom_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    sku = table.Column<string>(type: "varchar(50)", nullable: true),
                    barcode = table.Column<string>(type: "varchar(50)", nullable: true),
                    color = table.Column<string>(type: "varchar(50)", nullable: true),
                    size = table.Column<string>(type: "varchar(50)", nullable: true),
                    price = table.Column<decimal>(type: "decimal(16,4)", nullable: true),
                    stock_quantity = table.Column<int>(type: "int", nullable: true),
                    weight_kg = table.Column<decimal>(type: "decimal(16,4)", nullable: true),
                    length_cm = table.Column<decimal>(type: "decimal(16,4)", nullable: true),
                    width_cm = table.Column<decimal>(type: "decimal(16,4)", nullable: true),
                    height_cm = table.Column<decimal>(type: "decimal(16,4)", nullable: true),
                    chargeable_weight_kg = table.Column<decimal>(type: "decimal(16,4)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    updated_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    im_Productsproduct_id = table.Column<string>(type: "varchar(20)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_ProductVariants", x => x.variant_id);
                    table.ForeignKey(
                        name: "FK_im_ProductVariants_im_Products_im_Productsproduct_id",
                        column: x => x.im_Productsproduct_id,
                        principalTable: "im_Products",
                        principalColumn: "product_id");
                });

            migrationBuilder.CreateTable(
                name: "im_ProductImages",
                columns: table => new
                {
                    image_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    product_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    variant_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    image_url = table.Column<string>(type: "varchar(200)", nullable: true),
                    is_primary = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    display_order = table.Column<int>(type: "int", nullable: true),
                    uploaded_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    im_ProductVariantsvariant_id = table.Column<string>(type: "varchar(30)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_im_ProductImages", x => x.image_id);
                    table.ForeignKey(
                        name: "FK_im_ProductImages_im_ProductVariants_im_ProductVariantsvariant_id",
                        column: x => x.im_ProductVariantsvariant_id,
                        principalTable: "im_ProductVariants",
                        principalColumn: "variant_id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_im_ProductImages_im_ProductVariantsvariant_id",
                table: "im_ProductImages",
                column: "im_ProductVariantsvariant_id");

            migrationBuilder.CreateIndex(
                name: "IX_im_Products_im_ProductCategoriescategory_id",
                table: "im_Products",
                column: "im_ProductCategoriescategory_id");

            migrationBuilder.CreateIndex(
                name: "IX_im_ProductVariants_im_Productsproduct_id",
                table: "im_ProductVariants",
                column: "im_Productsproduct_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "im_ProductImages");

            migrationBuilder.DropTable(
                name: "im_ProductVariants");

            migrationBuilder.DropTable(
                name: "im_Products");

            migrationBuilder.DropTable(
                name: "im_ProductCategories");
        }
    }
}
