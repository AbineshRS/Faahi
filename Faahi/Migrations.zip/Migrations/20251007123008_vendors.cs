﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Faahi.Migrations
{
    /// <inheritdoc />
    public partial class vendors : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "am_vcos");

            migrationBuilder.CreateTable(
                name: "ap_Vendors",
                columns: table => new
                {
                    vendor_id = table.Column<string>(type: "varchar(30)", nullable: false),
                    vendor_code = table.Column<string>(type: "varchar(30)", nullable: true),
                    payment_term_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    preferred_payment_method = table.Column<string>(type: "varchar(20)", nullable: true),
                    withholding_tax_rate = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    ap_control_account = table.Column<string>(type: "varchar(40)", nullable: true),
                    note = table.Column<string>(type: "varchar(40)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    updated_at = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ap_Vendors", x => x.vendor_id);
                });

            migrationBuilder.CreateTable(
                name: "ar_Customers",
                columns: table => new
                {
                    customer_id = table.Column<string>(type: "varchar(20)", nullable: false),
                    price_tier_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    customer_code = table.Column<string>(type: "varchar(30)", nullable: true),
                    payment_term_id = table.Column<string>(type: "varchar(30)", nullable: true),
                    credit_limit = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    default_billing_address_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    default_shipping_address_id = table.Column<string>(type: "varchar(20)", nullable: true),
                    loyalty_points = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    loyalty_level = table.Column<string>(type: "varchar(40)", nullable: true),
                    note = table.Column<string>(type: "varchar(50)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    updated_at = table.Column<DateTime>(type: "datetime", nullable: true),
                    credit_hold = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true),
                    tax_exempt = table.Column<string>(type: "char(1)", maxLength: 1, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ar_Customers", x => x.customer_id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ap_Vendors");

            migrationBuilder.DropTable(
                name: "ar_Customers");

            migrationBuilder.CreateTable(
                name: "am_vcos",
                columns: table => new
                {
                    vcos_id = table.Column<string>(type: "varchar(16)", nullable: false),
                    Registered_date = table.Column<DateTime>(type: "datetime", nullable: false),
                    TIN = table.Column<string>(type: "varchar(20)", nullable: true),
                    address = table.Column<string>(type: "varchar(150)", nullable: true),
                    bank_account_number = table.Column<string>(type: "varchar(24)", nullable: true),
                    bank_code = table.Column<string>(type: "varchar(16)", nullable: true),
                    contact_person = table.Column<string>(type: "varchar(32)", nullable: true),
                    country = table.Column<string>(type: "varchar(32)", nullable: true),
                    credit_days = table.Column<int>(type: "int", nullable: true),
                    credit_limit_amount = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    currency_id = table.Column<string>(type: "varchar(16)", nullable: false),
                    current_balance = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    edit_date_time = table.Column<DateTime>(type: "datetime", nullable: false),
                    edit_user_id = table.Column<string>(type: "varchar(16)", nullable: false),
                    email = table.Column<string>(type: "varchar(100)", nullable: true),
                    fax = table.Column<string>(type: "varchar(32)", nullable: true),
                    name = table.Column<string>(type: "varchar(150)", nullable: false),
                    postal_code = table.Column<string>(type: "varchar(12)", nullable: true),
                    state = table.Column<string>(type: "varchar(32)", nullable: true),
                    status = table.Column<string>(type: "char(1)", maxLength: 1, nullable: false),
                    telephone_1 = table.Column<string>(type: "varchar(32)", nullable: true),
                    telephone_2 = table.Column<string>(type: "varchar(32)", nullable: true),
                    trade_discount_percent = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    vcos_type = table.Column<string>(type: "varchar(10)", nullable: true),
                    web = table.Column<string>(type: "varchar(100)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_am_vcos", x => x.vcos_id);
                });
        }
    }
}
